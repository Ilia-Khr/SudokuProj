﻿using Sudoku.InterfaceAndAbstract;
using System;
using System.Collections.Generic;
using System.Text;

namespace Sudoku.GameModel
{
    public class Record : AbstractSession
    {
        public string GamerName { get; set; }
    }
}
